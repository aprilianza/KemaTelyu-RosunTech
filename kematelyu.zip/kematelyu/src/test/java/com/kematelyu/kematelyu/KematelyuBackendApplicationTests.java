package com.kematelyu.kematelyu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KematelyuBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
